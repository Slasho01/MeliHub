# Ventoki Sync (WooCommerce)

Plugin que conecta una tienda WooCommerce con **Ventoki**: trae los productos
(con el precio del canal) y reporta las ventas para mantener el stock
sincronizado en dos vías (WooCommerce ↔ Ventoki ↔ Mercado Libre).

## Instalación
1. Comprime la carpeta `ventoki-sync` en un `.zip`.
2. En WordPress: **Plugins → Añadir nuevo → Subir plugin** → sube el `.zip` → **Activar**.
   (Requiere WooCommerce activo.)
3. Ve a **WooCommerce → Ventoki Sync** y configura:
   - **URL de Ventoki**: ej. `https://ventoki.onrender.com`
   - **API Key**: créala en Ventoki → *API keys* (elige el canal que corresponda).
4. Pulsa **Sincronizar ahora**. Luego se sincroniza solo cada 15 minutos.

## Qué hace
- **Importa** los productos de Ventoki a WooCommerce (los empareja por SKU = ID de
  Mercado Libre; guarda el id de Ventoki como metadato para reportar ventas).
  Actualiza nombre, precio, stock, estado, descripción, ficha técnica (atributos)
  y categoría. La imagen se (re)descarga si cambia.
- La sincronización se hace **por páginas** (50 a la vez), así que no se cae con
  catálogos grandes; si un producto falla, sigue con el resto y lo reporta.
- Al **vender** en WooCommerce, descuenta stock en Ventoki (que a su vez lo baja
  en Mercado Libre).
- Cada 15 min **re-sincroniza** para reflejar ventas ocurridas en Mercado Libre.
- **Ocultar retirados** (opcional): los productos que ya no vienen de Ventoki se
  pasan a borrador automáticamente.
- **Probar conexión**: verifica URL + API key y muestra cuántos productos hay en
  el canal, antes de sincronizar.

## Notas
- Ventoki debe estar accesible por HTTPS desde el servidor de WordPress.
- La API key define qué productos y qué precio de canal recibe esta tienda.
