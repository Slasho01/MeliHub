<?php
/**
 * Plugin Name: Ventoki Sync
 * Description: Sincroniza productos de Ventoki (Mercado Libre) a WooCommerce y reporta las ventas para mantener el stock en dos vías.
 * Version: 0.7.1
 * Author: Jarstore
 * Requires Plugins: woocommerce
 */

if (!defined('ABSPATH')) exit;

define('VENTOKI_META_ID', '_ventoki_id');
define('VENTOKI_PAGE', 50);  // productos por página al sincronizar (cron)
define('VENTOKI_BATCH', 5);  // productos por lote AJAX (evita timeouts del servidor web)

/* ----------------------------- Config ----------------------------- */

function ventoki_opts() {
    return [
        'url'      => rtrim(get_option('ventoki_url', ''), '/'),
        'key'      => get_option('ventoki_key', ''),
        'huerfanos'=> get_option('ventoki_huerfanos', '0') === '1', // ocultar los que ya no vienen
    ];
}

/** Llama a la API pública de Ventoki con la API key. $path puede incluir query. */
function ventoki_api($method, $path, $body = null, &$headers_out = null) {
    $o = ventoki_opts();
    if (!$o['url'] || !$o['key']) {
        return new WP_Error('ventoki', 'Falta configurar la URL y la API key de Ventoki.');
    }
    $args = [
        'method'  => $method,
        'timeout' => 30,
        'headers' => ['X-API-Key' => $o['key'], 'Accept' => 'application/json', 'ngrok-skip-browser-warning' => '1'],
    ];
    if ($body !== null) {
        $args['headers']['Content-Type'] = 'application/json';
        $args['body'] = wp_json_encode($body);
    }
    $res = wp_remote_request($o['url'] . '/api/pub' . $path, $args);
    if (is_wp_error($res)) return $res;
    $code = wp_remote_retrieve_response_code($res);
    $data = json_decode(wp_remote_retrieve_body($res), true);
    if ($code < 200 || $code >= 300) {
        return new WP_Error('ventoki', 'Ventoki respondió ' . $code . ': ' . (isset($data['error']) ? $data['error'] : ''));
    }
    if ($headers_out !== null) {
        $headers_out = ['total' => (int) wp_remote_retrieve_header($res, 'x-total-count')];
    }
    return $data;
}

/* ----------------------------- Importar productos ----------------------------- */

/** Crea/actualiza UN producto de Ventoki en WooCommerce. Devuelve [id, nuevo]. */
function ventoki_upsert_producto($it) {
    // SKU ESTABLE del hub (catalog_product_id o item id): evita duplicar cuando el
    // representante salta entre la publicación de catálogo y la normal.
    $sku = !empty($it['sku']) ? $it['sku'] : $it['ml_item_id'];
    $product_id = wc_get_product_id_by_sku($sku);
    // Migración: si no existe con el SKU nuevo, búscalo por el id del hub (meta) o por el
    // item id antiguo, y re-apunta su SKU — así no se crea un duplicado.
    if (!$product_id && !empty($it['id'])) {
        $prev = wc_get_products(['limit' => 1, 'return' => 'ids', 'meta_key' => VENTOKI_META_ID, 'meta_value' => $it['id']]);
        if (!empty($prev)) $product_id = (int) $prev[0];
    }
    if (!$product_id && !empty($it['ml_item_id']) && $it['ml_item_id'] !== $sku) {
        $product_id = wc_get_product_id_by_sku($it['ml_item_id']);
    }
    $tiene_variantes = !empty($it['variantes']) && is_array($it['variantes']);

    // Tipo correcto (simple/variable). Si el existente es de otro tipo, se cambia.
    if ($product_id) {
        $tipo_deseado = $tiene_variantes ? 'variable' : 'simple';
        if (WC_Product_Factory::get_product_type($product_id) !== $tipo_deseado) {
            wp_set_object_terms($product_id, $tipo_deseado, 'product_type');
        }
        $product = $tiene_variantes ? new WC_Product_Variable($product_id) : new WC_Product_Simple($product_id);
    } else {
        $product = $tiene_variantes ? new WC_Product_Variable() : new WC_Product_Simple();
    }
    $nuevo = !$product_id;

    $product->set_name($it['titulo']);
    $product->set_sku($sku);
    $product->set_status($it['estado'] === 'active' ? 'publish' : 'draft');
    if (!empty($it['descripcion'])) $product->set_description($it['descripcion']);
    ventoki_set_video($product, $it['video'] ?? '');

    if ($tiene_variantes) {
        // En variables, el precio y el stock los manejan las variaciones.
        $product->set_manage_stock(false);
    } else {
        $product->set_regular_price((string) $it['precio']);
        $product->set_manage_stock(true);
        $product->set_stock_quantity((int) $it['stock']);
        $product->set_stock_status($it['stock'] > 0 ? 'instock' : 'outofstock');
    }

    // Atributos: ficha técnica (no-variación) + los de variación (color/talla/etc.).
    $attrs = [];
    $pos = 0;
    if (!empty($it['especificaciones']) && is_array($it['especificaciones'])) {
        foreach ($it['especificaciones'] as $spec) {
            if (empty($spec['nombre']) || empty($spec['valor'])) continue;
            $a = new WC_Product_Attribute();
            $a->set_id(0); $a->set_name($spec['nombre']); $a->set_options([$spec['valor']]);
            $a->set_position($pos++); $a->set_visible(true); $a->set_variation(false);
            $attrs[] = $a;
        }
    }
    if ($tiene_variantes) {
        $varmap = []; // nombre_atributo => valores distintos
        foreach ($it['variantes'] as $v) {
            foreach (($v['atributos'] ?? []) as $a) {
                if (empty($a['nombre']) || empty($a['valor'])) continue;
                $varmap[$a['nombre']][$a['valor']] = true;
            }
        }
        foreach ($varmap as $nombre => $valset) {
            $a = new WC_Product_Attribute();
            $a->set_id(0); $a->set_name($nombre); $a->set_options(array_keys($valset));
            $a->set_position($pos++); $a->set_visible(true); $a->set_variation(true);
            $attrs[] = $a;
        }
    }
    if ($attrs) $product->set_attributes($attrs);

    // Categorías anidadas (raíz→hoja). Si el hub manda la ruta completa, se jerarquizan;
    // si no, cae a la categoría simple. El producto queda en la categoría HOJA.
    $ruta = (!empty($it['categoria_ruta']) && is_array($it['categoria_ruta']))
        ? $it['categoria_ruta']
        : (!empty($it['categoria']) ? [$it['categoria']] : []);
    $cat_id = ventoki_categorias_desde_ruta($ruta);
    if ($cat_id) $product->set_category_ids([$cat_id]);
    $product->update_meta_data(VENTOKI_META_ID, $it['id']);
    $id = $product->save();

    // Galería del producto (padre). En variables, cada variación tiene además su imagen.
    $imgs = !empty($it['imagenes']) && is_array($it['imagenes']) ? $it['imagenes'] : array_filter([$it['thumbnail'] ?? '']);
    ventoki_sync_imagenes($product, $imgs);
    if ($tiene_variantes) {
        ventoki_sync_variantes($product, $it['variantes']);
    }
    return [$id, $nuevo];
}

/** Firma normalizada de una combinación de atributos [slug => valor] (para emparejar variaciones). */
function ventoki_var_firma($attrs) {
    $norm = [];
    foreach ((array) $attrs as $k => $val) {
        $norm[sanitize_title($k)] = sanitize_title($val);
    }
    ksort($norm);
    return md5(wp_json_encode($norm));
}

/** Crea/actualiza las variaciones de WooCommerce desde las variantes de Ventoki. */
function ventoki_sync_variantes($product, $variantes) {
    $parent_id = $product->get_id();
    // Variaciones existentes, indexadas por la firma de sus atributos (para no duplicar).
    $existentes = [];
    foreach ($product->get_children() as $cid) {
        $cv = wc_get_product($cid);
        if ($cv) $existentes[ventoki_var_firma($cv->get_attributes())] = $cid;
    }
    $vistas = [];
    foreach ($variantes as $v) {
        $va = [];
        foreach (($v['atributos'] ?? []) as $a) {
            if (empty($a['nombre']) || empty($a['valor'])) continue;
            $va[sanitize_title($a['nombre'])] = $a['valor'];
        }
        if (!$va) continue;
        $firma = ventoki_var_firma($va);
        $vistas[$firma] = true;
        $variation = isset($existentes[$firma]) ? wc_get_product($existentes[$firma]) : new WC_Product_Variation();
        $variation->set_parent_id($parent_id);
        $variation->set_attributes($va);
        $variation->set_regular_price((string) ($v['precio'] ?? 0));
        $variation->set_manage_stock(true);
        $variation->set_stock_quantity((int) ($v['stock'] ?? 0));
        $variation->set_stock_status(($v['stock'] ?? 0) > 0 ? 'instock' : 'outofstock');
        $vid = $variation->save();
        // Imagen propia de la variante (una firma para no re-subir).
        if (!empty($v['imagenes'][0])) {
            $firma_img = md5($v['imagenes'][0]);
            if (get_post_meta($vid, '_ventoki_var_img', true) !== $firma_img) {
                require_once(ABSPATH . 'wp-admin/includes/media.php');
                require_once(ABSPATH . 'wp-admin/includes/file.php');
                require_once(ABSPATH . 'wp-admin/includes/image.php');
                $att = media_sideload_image($v['imagenes'][0], $parent_id, null, 'id');
                if (!is_wp_error($att)) {
                    $variation->set_image_id((int) $att);
                    $variation->save();
                    update_post_meta($vid, '_ventoki_var_img', $firma_img);
                }
            }
        }
    }
    // Elimina variaciones que ya no vienen del hub.
    foreach ($existentes as $firma => $cid) {
        if (empty($vistas[$firma])) {
            $c = wc_get_product($cid);
            if ($c) $c->delete(true);
        }
    }
    if (class_exists('WC_Product_Variable')) {
        WC_Product_Variable::sync($parent_id);
    }
}

/** Descarga la galería: 1ª imagen = destacada, el resto = galería del producto. */
function ventoki_sync_imagenes($product, $imagenes) {
    $imagenes = array_values(array_filter((array) $imagenes));
    if (!$imagenes) return;
    $id = $product->get_id();
    $firma = md5(implode('|', $imagenes));
    if (get_post_meta($id, '_ventoki_img_firma', true) === $firma) return; // sin cambios
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    $ids = [];
    foreach ($imagenes as $url) {
        $att = media_sideload_image($url, $id, null, 'id');
        if (!is_wp_error($att)) $ids[] = (int) $att;
    }
    if (!$ids) return;
    set_post_thumbnail($id, $ids[0]);
    $product->set_gallery_image_ids(count($ids) > 1 ? array_slice($ids, 1) : []);
    $product->save();
    update_post_meta($id, '_ventoki_img_firma', $firma);
}

/** Inserta/actualiza el video (YouTube) en la descripción, para que WordPress lo embeba.
 *  La URL va sola en su línea (auto-embed) entre marcadores, para reemplazarla en cada sync. */
function ventoki_set_video($product, $video) {
    $desc = (string) $product->get_description();
    $desc = preg_replace('#\s*<!--ventoki-video-->.*?<!--/ventoki-video-->#s', '', $desc);
    $video = trim((string) $video);
    if ($video !== '') {
        $desc = rtrim($desc) . "\n\n<!--ventoki-video-->\n" . esc_url_raw($video) . "\n<!--/ventoki-video-->";
    }
    $product->set_description($desc);
}

/** Crea/encuentra la cadena de categorías product_cat a partir de la ruta (raíz→hoja),
 *  ANIDÁNDOLAS (cada nivel es hijo del anterior). Devuelve el term_id de la HOJA (donde
 *  va el producto). Marca cada nivel con `_ventoki_cat` para gestionarlo en el menú.
 *  Robusto ante "term_exists" y busca por nombre DENTRO del padre (ramas distintas). */
function ventoki_categorias_desde_ruta($ruta) {
    $ruta = array_values(array_filter(array_map('trim', (array) $ruta), 'strlen'));
    if (!$ruta) return 0;
    $parent = 0; $leaf = 0;
    foreach ($ruta as $nombre) {
        $existing = get_terms([
            'taxonomy' => 'product_cat', 'hide_empty' => false,
            'name' => $nombre, 'parent' => $parent, 'number' => 1,
        ]);
        if (!is_wp_error($existing) && !empty($existing)) {
            $tid = (int) $existing[0]->term_id;
        } else {
            $r = wp_insert_term($nombre, 'product_cat', ['parent' => $parent]);
            if (is_wp_error($r)) {
                $data = $r->get_error_data();
                if (is_array($data) && !empty($data['term_id'])) $tid = (int) $data['term_id'];
                elseif (is_int($data)) $tid = (int) $data;
                else $tid = 0;
            } else {
                $tid = (int) $r['term_id'];
            }
        }
        if (!$tid) break;
        if (!get_term_meta($tid, '_ventoki_cat', true)) add_term_meta($tid, '_ventoki_cat', '1', true);
        $parent = $tid; $leaf = $tid;
    }
    return $leaf;
}

/** Profundidad de un término en el árbol Ventoki (para ordenar padres antes que hijos). */
function ventoki_prof_term($tid, $by_id) {
    $d = 0; $cur = (int) $tid;
    while ($cur && isset($by_id[$cur])) {
        $p = (int) $by_id[$cur]->parent;
        if (!$p || !isset($by_id[$p])) break;
        $d++; $cur = $p;
        if ($d > 20) break; // guardia anti-ciclo
    }
    return $d;
}

/** Añade al menú elegido las categorías de Ventoki RESPETANDO LA JERARQUÍA (padre →
 *  submenú). Incluye las categorías con productos y sus ancestros; evita duplicados y
 *  solo re-parenta los ítems que creó Ventoki (no toca lo que el usuario puso a mano).
 *  Devuelve cuántos ítems nuevos añadió. */
function ventoki_sync_menu_categorias() {
    $menu_id = (int) get_option('ventoki_menu', 0);
    if (!$menu_id) return 0; // desactivado: el usuario no eligió menú
    if (!wp_get_nav_menu_object($menu_id)) return 0;

    // Todas las categorías Ventoki con su parent (SIN hide_empty: un padre puede tener
    // count 0 pero hijos con productos).
    $terms = get_terms([
        'taxonomy'   => 'product_cat',
        'hide_empty' => false,
        'meta_query' => [['key' => '_ventoki_cat', 'value' => '1']],
    ]);
    if (is_wp_error($terms) || !$terms) return 0;

    $by_id = [];
    foreach ($terms as $t) $by_id[(int) $t->term_id] = $t;

    // Incluir términos con productos + toda su cadena de ancestros (sin ramas vacías).
    $incluir = [];
    foreach ($terms as $t) {
        if ((int) $t->count <= 0) continue;
        $cur = (int) $t->term_id;
        while ($cur && isset($by_id[$cur]) && !isset($incluir[$cur])) {
            $incluir[$cur] = true;
            $cur = (int) $by_id[$cur]->parent;
        }
    }
    if (!$incluir) return 0;

    // Ítems de menú existentes (product_cat): term_id -> menu_item_id, y cuáles son nuestros.
    $items = wp_get_nav_menu_items($menu_id);
    $item_de_term = [];
    $es_mio = [];
    if (is_array($items)) {
        foreach ($items as $mi) {
            if ($mi->type === 'taxonomy' && $mi->object === 'product_cat') {
                $item_de_term[(int) $mi->object_id] = (int) $mi->ID;
                if (get_post_meta($mi->ID, '_ventoki_menu', true)) $es_mio[(int) $mi->ID] = true;
            }
        }
    }

    // Procesar de raíz a hoja para poder enlazar el padre antes que el hijo.
    $orden = array_keys($incluir);
    usort($orden, function ($a, $b) use ($by_id) {
        return ventoki_prof_term($a, $by_id) <=> ventoki_prof_term($b, $by_id);
    });

    $add = 0;
    foreach ($orden as $tid) {
        $t = $by_id[$tid];
        $ptid = (int) $t->parent;
        $parent_item = (isset($incluir[$ptid]) && isset($item_de_term[$ptid])) ? (int) $item_de_term[$ptid] : 0;

        if (isset($item_de_term[$tid])) {
            // Ya está en el menú: si es nuestro, corrige el padre si cambió.
            $iid = (int) $item_de_term[$tid];
            if (isset($es_mio[$iid])) {
                $actual = (int) get_post_meta($iid, '_menu_item_menu_item_parent', true);
                if ($actual !== $parent_item) {
                    wp_update_nav_menu_item($menu_id, $iid, [
                        'menu-item-object'    => 'product_cat',
                        'menu-item-object-id' => $tid,
                        'menu-item-type'      => 'taxonomy',
                        'menu-item-parent-id' => $parent_item,
                        'menu-item-status'    => 'publish',
                    ]);
                }
            }
            continue;
        }
        // Crear el ítem anidado.
        $iid = wp_update_nav_menu_item($menu_id, 0, [
            'menu-item-title'     => $t->name,
            'menu-item-object'    => 'product_cat',
            'menu-item-object-id' => $tid,
            'menu-item-type'      => 'taxonomy',
            'menu-item-parent-id' => $parent_item,
            'menu-item-status'    => 'publish',
        ]);
        if (!is_wp_error($iid)) {
            update_post_meta($iid, '_ventoki_menu', '1');
            $item_de_term[$tid] = (int) $iid; // para que los hijos lo encuentren
            $es_mio[(int) $iid] = true;
            $add++;
        }
    }
    return $add;
}

/** Trae TODOS los productos (por páginas) y los sincroniza en WooCommerce. */
function ventoki_sync_productos() {
    if (function_exists('set_time_limit')) @set_time_limit(0);

    $creados = 0; $actualizados = 0; $errores = 0; $total_api = 0;
    $vistos = [];      // ventoki_id que siguen viniendo (para detectar huérfanos)
    $offset = 0;

    do {
        $h = [];
        $items = ventoki_api('GET', '/productos?limit=' . VENTOKI_PAGE . '&offset=' . $offset, null, $h);
        if (is_wp_error($items)) return $items;
        $total_api = $h['total'] ?: $total_api;
        if (!is_array($items) || count($items) === 0) break;

        foreach ($items as $it) {
            try {
                list($id, $nuevo) = ventoki_upsert_producto($it);
                $vistos[] = $it['id'];
                $nuevo ? $creados++ : $actualizados++;
            } catch (\Throwable $e) {
                $errores++;
                error_log('Ventoki: error en ' . ($it['ml_item_id'] ?? '?') . ': ' . $e->getMessage());
            }
        }
        $offset += count($items);
    } while (count($items) === VENTOKI_PAGE);

    // Huérfanos: productos con ventoki_id que ya no vienen -> a borrador (ocultar).
    $ocultos = 0;
    $o = ventoki_opts();
    if ($o['huerfanos'] && $vistos) {
        $ocultos = ventoki_ocultar_huerfanos($vistos);
    }

    // Añade las categorías nuevas al menú elegido (si el usuario configuró uno).
    $menu_add = ventoki_sync_menu_categorias();

    $resultado = [
        'creados' => $creados, 'actualizados' => $actualizados, 'errores' => $errores,
        'ocultos' => $ocultos, 'menu' => $menu_add, 'total' => $total_api ?: ($creados + $actualizados),
        'fecha' => current_time('mysql'),
    ];
    update_option('ventoki_last_sync', $resultado['fecha']);
    update_option('ventoki_last_result', $resultado);
    return $resultado;
}

/** Pone en borrador los productos Ventoki que ya no aparecen en el feed. */
function ventoki_ocultar_huerfanos($vistos_ids) {
    $ids = get_posts([
        'post_type'   => 'product',
        'post_status' => 'publish',
        'numberposts' => -1,
        'fields'      => 'ids',
        'meta_key'    => VENTOKI_META_ID,
    ]);
    $set = array_flip($vistos_ids);
    $n = 0;
    foreach ($ids as $pid) {
        $mid = get_post_meta($pid, VENTOKI_META_ID, true);
        if ($mid && !isset($set[$mid])) {
            wp_update_post(['ID' => $pid, 'post_status' => 'draft']);
            $n++;
        }
    }
    return $n;
}

/* --------------------- Sincronización por lotes (AJAX) --------------------- */
// Procesa el catálogo en lotes pequeños para no exceder el timeout del servidor web.
// El JS del panel llama este endpoint en bucle hasta terminar (con barra de progreso).
add_action('wp_ajax_ventoki_sync_batch', 'ventoki_ajax_sync_batch');
function ventoki_ajax_sync_batch() {
    check_ajax_referer('ventoki_sync_ajax', 'nonce');
    if (!current_user_can('manage_woocommerce')) wp_send_json_error(['msg' => 'Sin permiso'], 403);
    if (function_exists('set_time_limit')) @set_time_limit(0);

    $offset = isset($_POST['offset']) ? max(0, (int) $_POST['offset']) : 0;
    $reset  = !empty($_POST['reset']);

    $state = $reset ? null : get_transient('ventoki_sync_state');
    if (!is_array($state)) {
        $state = ['creados' => 0, 'actualizados' => 0, 'errores' => 0, 'vistos' => [], 'total' => 0];
        $offset = 0;
    }

    $h = [];
    $items = ventoki_api('GET', '/productos?limit=' . VENTOKI_BATCH . '&offset=' . $offset, null, $h);
    if (is_wp_error($items)) {
        delete_transient('ventoki_sync_state');
        wp_send_json_error(['msg' => $items->get_error_message()]);
    }
    if (!empty($h['total'])) $state['total'] = (int) $h['total'];
    $n = is_array($items) ? count($items) : 0;

    foreach ((array) $items as $it) {
        try {
            list($id, $nuevo) = ventoki_upsert_producto($it);
            $state['vistos'][] = $it['id'];
            $nuevo ? $state['creados']++ : $state['actualizados']++;
        } catch (\Throwable $e) {
            $state['errores']++;
            error_log('Ventoki: error en ' . ($it['ml_item_id'] ?? '?') . ': ' . $e->getMessage());
        }
    }

    $new_offset = $offset + $n;
    $done = $n < VENTOKI_BATCH; // la última página trae menos que el lote

    if ($done) {
        // Cierre: ocultar huérfanos (si está activado) y armar el menú UNA vez.
        $o = ventoki_opts();
        $ocultos = ($o['huerfanos'] && $state['vistos']) ? ventoki_ocultar_huerfanos($state['vistos']) : 0;
        $menu = ventoki_sync_menu_categorias();
        $result = [
            'creados' => $state['creados'], 'actualizados' => $state['actualizados'], 'errores' => $state['errores'],
            'ocultos' => $ocultos, 'menu' => $menu,
            'total' => $state['total'] ?: ($state['creados'] + $state['actualizados']),
            'fecha' => current_time('mysql'),
        ];
        update_option('ventoki_last_sync', $result['fecha']);
        update_option('ventoki_last_result', $result);
        delete_transient('ventoki_sync_state');
        wp_send_json_success(['done' => true, 'procesados' => $new_offset, 'result' => $result]);
    }
    set_transient('ventoki_sync_state', $state, HOUR_IN_SECONDS);
    wp_send_json_success(['done' => false, 'offset' => $new_offset, 'procesados' => $new_offset, 'total' => $state['total']]);
}

/* ----------------------------- Reportar ventas ----------------------------- */

add_action('woocommerce_reduce_order_stock', function ($order) {
    foreach ($order->get_items() as $item) {
        $product = $item->get_product();
        if (!$product) continue;
        $mid = $product->get_meta(VENTOKI_META_ID);
        if (!$mid) continue;
        $qty = (int) $item->get_quantity();
        if ($qty <= 0) continue;
        $r = ventoki_api('POST', '/ventas', ['producto_id' => $mid, 'cantidad' => $qty]);
        if (is_wp_error($r)) {
            error_log('Ventoki: no se pudo reportar venta de ' . $product->get_sku() . ': ' . $r->get_error_message());
        }
    }
});

/* ----------------------------- Sincronización periódica ----------------------------- */

add_filter('cron_schedules', function ($s) {
    $s['ventoki_15min'] = ['interval' => 900, 'display' => 'Cada 15 minutos (Ventoki)'];
    return $s;
});
register_activation_hook(__FILE__, function () {
    if (!wp_next_scheduled('ventoki_cron_sync')) wp_schedule_event(time() + 60, 'ventoki_15min', 'ventoki_cron_sync');
});
register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('ventoki_cron_sync');
});
add_action('ventoki_cron_sync', 'ventoki_sync_productos');

/* ----------------------------- Panel de administración ----------------------------- */

add_action('admin_menu', function () {
    add_submenu_page('woocommerce', 'Ventoki Sync', 'Ventoki Sync', 'manage_woocommerce', 'ventoki-sync', 'ventoki_admin_page');
});

add_action('admin_init', function () {
    register_setting('ventoki', 'ventoki_url');
    register_setting('ventoki', 'ventoki_key');
    register_setting('ventoki', 'ventoki_huerfanos');
    register_setting('ventoki', 'ventoki_menu');
});

function ventoki_admin_page() {
    $msg = '';
    if (isset($_POST['ventoki_test']) && check_admin_referer('ventoki_test_c')) {
        $h = [];
        $r = ventoki_api('GET', '/productos?limit=1', null, $h);
        $msg = is_wp_error($r)
            ? '<div class="notice notice-error"><p>Conexión fallida: ' . esc_html($r->get_error_message()) . '</p></div>'
            : '<div class="notice notice-success"><p>Conexión OK. Productos disponibles en este canal: <b>' . intval($h['total']) . '</b>.</p></div>';
    }
    $o = ventoki_opts();
    $last = get_option('ventoki_last_sync', 'nunca');
    $lr = get_option('ventoki_last_result', null);
    ?>
    <div class="wrap">
        <h1 style="display:flex;align-items:center;gap:12px;">
            <svg width="40" height="40" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style="flex:0 0 auto;">
                <defs><linearGradient id="ventoki_vk" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#8B7BFF"/><stop offset="1" stop-color="#5B4FE0"/></linearGradient></defs>
                <rect x="2" y="2" width="60" height="60" rx="15" fill="url(#ventoki_vk)"/>
                <path d="M19 20 L32 45 L45 20" fill="none" stroke="#ffffff" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>
                <circle cx="45" cy="20" r="4.6" fill="#ffffff"/>
            </svg>
            <span>Vent<span style="color:#5B4FE0;">oki</span> Sync</span>
        </h1>
        <?php echo $msg; ?>
        <form method="post" action="options.php">
            <?php settings_fields('ventoki'); ?>
            <table class="form-table">
                <tr><th>URL de Ventoki</th><td><input type="url" name="ventoki_url" value="<?php echo esc_attr($o['url']); ?>" class="regular-text" placeholder="https://ventoki.onrender.com" /></td></tr>
                <tr><th>API Key</th><td><input type="password" name="ventoki_key" value="<?php echo esc_attr($o['key']); ?>" class="regular-text" placeholder="mhk_..." /><p class="description">Créala en Ventoki → API keys (nombre de tu canal).</p></td></tr>
                <tr><th>Ocultar retirados</th><td><label><input type="checkbox" name="ventoki_huerfanos" value="1" <?php checked($o['huerfanos']); ?> /> Poner en borrador los productos que ya no vienen de Ventoki.</label></td></tr>
                <tr><th>Añadir categorías al menú</th><td>
                    <?php $menus = wp_get_nav_menus(); $sel = (int) get_option('ventoki_menu', 0); ?>
                    <select name="ventoki_menu">
                        <option value="0"><?php esc_html_e('— No añadir al menú —'); ?></option>
                        <?php foreach ($menus as $m): ?>
                            <option value="<?php echo (int) $m->term_id; ?>" <?php selected($sel, (int) $m->term_id); ?>><?php echo esc_html($m->name); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description">Las categorías de los productos sincronizados se agregan a este menú <b>con su jerarquía (padre › submenús)</b>, sin duplicar y sin tocar lo que pusiste a mano.
                    <?php if (!$menus): ?><br><b>No tienes menús.</b> Crea uno en Apariencia → Menús y vuelve aquí.<?php endif; ?></p>
                </td></tr>
            </table>
            <?php submit_button('Guardar'); ?>
        </form>
        <hr>
        <p>Última sincronización: <b><?php echo esc_html($last); ?></b> · automática cada 15 minutos.
        <?php if (is_array($lr)): ?>
            <br>Último resultado: <?php echo intval($lr['creados']); ?> creados, <?php echo intval($lr['actualizados']); ?> actualizados<?php
                if (!empty($lr['errores'])) echo ', <span style="color:#b32d2e">' . intval($lr['errores']) . ' con error</span>';
                if (!empty($lr['ocultos'])) echo ', ' . intval($lr['ocultos']) . ' ocultados';
            ?>.
        <?php endif; ?></p>
        <button class="button button-primary" id="ventoki-sync-btn">Sincronizar ahora</button>
        <span id="ventoki-sync-prog" style="margin-left:10px; font-weight:600"></span>
        <form method="post" style="display:inline; margin-left:8px">
            <?php wp_nonce_field('ventoki_test_c'); ?>
            <button class="button" name="ventoki_test" value="1">Probar conexión</button>
        </form>
        <p class="description" style="margin-top:8px">La sincronización corre en lotes pequeños (sin timeouts); no cierres esta pestaña hasta que termine.</p>
        <script>
        (function () {
            var btn = document.getElementById('ventoki-sync-btn');
            var prog = document.getElementById('ventoki-sync-prog');
            if (!btn) return;
            var ajaxurl = <?php echo wp_json_encode(admin_url('admin-ajax.php')); ?>;
            var nonce = <?php echo wp_json_encode(wp_create_nonce('ventoki_sync_ajax')); ?>;
            function lote(offset, reset) {
                var body = new URLSearchParams({ action: 'ventoki_sync_batch', nonce: nonce, offset: offset, reset: reset ? '1' : '' });
                return fetch(ajaxurl, { method: 'POST', credentials: 'same-origin', body: body }).then(function (r) { return r.json(); });
            }
            btn.addEventListener('click', function (e) {
                e.preventDefault();
                btn.disabled = true;
                var offset = 0, first = true;
                prog.textContent = 'Iniciando…';
                function paso() {
                    lote(offset, first).then(function (res) {
                        first = false;
                        if (!res || !res.success) {
                            prog.textContent = '❌ Error: ' + ((res && res.data && res.data.msg) || 'desconocido');
                            btn.disabled = false; return;
                        }
                        var d = res.data;
                        if (d.done) {
                            var x = d.result;
                            prog.innerHTML = '✅ ' + x.creados + ' creados, ' + x.actualizados + ' actualizados'
                                + (x.errores ? ', ' + x.errores + ' con error' : '')
                                + (x.ocultos ? ', ' + x.ocultos + ' ocultados' : '')
                                + (x.menu ? ', ' + x.menu + ' al menú' : '') + '.';
                            btn.disabled = false; return;
                        }
                        offset = d.offset;
                        prog.textContent = 'Sincronizando… ' + d.procesados + (d.total ? ' / ' + d.total : '') + ' productos';
                        paso();
                    }).catch(function (err) {
                        prog.textContent = '❌ Error: ' + err.message; btn.disabled = false;
                    });
                }
                paso();
            });
        })();
        </script>
    </div>
    <?php
}
